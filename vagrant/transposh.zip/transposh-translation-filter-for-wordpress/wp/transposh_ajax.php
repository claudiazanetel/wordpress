<?php

/*
 * Transposh v0.9.9.1
 * http://transposh.org/
 *
 * Copyright 2016, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Sun, 15 May 2016 11:33:49 +0300
 */

/*
 * This file handles various AJAX needs of our plugin
 */

echo "This file was removed in 0.8.0 and is only kept for debugging";

?>