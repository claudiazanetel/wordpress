/*
 * Transposh v0.9.9.1
 * http://transposh.org/
 *
 * Copyright 2016, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Sun, 15 May 2016 11:33:49 +0300
 */
(function(a){a(function(){a("#sortable").sortable({placeholder:"highlight"});a("#sortable").disableSelection()})})(jQuery);
