/*
 * Transposh v0.9.9.1
 * http://transposh.org/
 *
 * Copyright 2016, Team Transposh
 * Licensed under the GPL Version 2 or higher.
 * http://transposh.org/license
 *
 * Date: Sun, 15 May 2016 11:33:49 +0300
 */
t_jp.l={"Close without saving?":"Fermer sans sauvegarder ?","You have made a change to the translation. Are you sure you want to discard it?":"Vous avez fait une modification de la traduction. Etes vous s&ucirc; de ne pas vouloir la garder ?",History:"Historique","Loading...":"Chargement...",Translated:"Traduit",By:"Par",At:"A",google:"google",bing:"bing",apertium:"apertium","manual translation":"traduction manuelle","bing suggest":"bing sugg&egrave;re","google suggest":"google sugg&egrave;re","apertium suggest":"apertium sugg&egrave;re",
"Edit Translation":"Modifier la traduction","Original text":"Texte original","read alternate translations":"Lire des traductions alternatives","previous translation":"traduction pr&eacute;c&eacute;dente","find on page":"trouver &agrave; la page","next translation":"traduction suivante","Translate to":"Traduire en","view translation log":"Voir le journal de traduction","virtual keyboard":"clavier virtuel","approve translation":"approuver la traduction","delete":"supprimer",Discard:"Abandonner",Cancel:"Annuler"};
